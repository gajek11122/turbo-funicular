# InstaBrute
> Multithreading Instagram Account password bruteforcer

![stability stable](http://b.repl.ca/v1/stability-stable-brightgreen.png)

    .-------------------------------------------------------.
    | |\___/|       ___           _                         |
    | )     (      |_ _|_ __  ___| |_ __ _                  |
    |=\     /=      | || '_ \/ __| __/ _` |                 |
    |  )===(        | || | | \__ \ || (_| |                 |
    | /     \      |___|_| |_|___/\__\__,_|                 |
    | |     |                                               |
    |/       \           _     ____  _   _ _____ _____      |
    |\       /          | |__ |  _ \| | | |_   _| ____|     |
    | \__  _/           | '_ \| |_) | | | | | | |  _|       |
    |   ( (             | |_) |  _ <| |_| | | | | |___      |
    |    ) )            |_.__/|_| \_\_____/ |_| |_____|     |
    |   (_(                                                 |
    '-------------------------------------------------------'
    

**[Warning] I take no responsibility for the use of this script [Warning]**

Cracking instagram account password by giving password list file and support proxy

### Usage

```./instabrute.py [-h] -u USERNAME -w WORD -p PROXY [-t THREAD] [-v] [-d]```

``` ./instabrute -u user_test -w words.txt -p proxys.txt -t 4 -d -v```

### Requirements

* Noting :)

### TODO

- [x] Remove additional dependencies
- [x] Add support for both python 3 and 2
- [x] Add log and verbose option
- [ ] Multi account support (![#8](https://github.com/N3TC4T/InstaBrute/issues/8))
- [ ] Save good proxies (![#7](https://github.com/N3TC4T/InstaBrute/issues/7))
- [ ] GUI for script


## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## Donate :)

![Bitcoin Donate Button](https://www.drupal.org/files/project-images/bitcoindonate.png)

Address : **16DVYPdR9sBBREvtzMEHbM1wTTHLTUgFNr**
